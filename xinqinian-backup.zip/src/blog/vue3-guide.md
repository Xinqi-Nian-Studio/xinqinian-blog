---
title: Vue 3 入门指南
date: 2024-05-15
author: 新启年工作室
# 核心：添加分类和标签
category: 前端开发
tags:
  - Vue3
  - 前端框架
  - 教程
---

Vue 3 带来了许多新特性和改进...