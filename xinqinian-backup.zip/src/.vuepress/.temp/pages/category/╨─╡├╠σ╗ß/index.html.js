import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/category/心得体会/index.html.vue"
const data = JSON.parse("{\"path\":\"/category/%E5%BF%83%E5%BE%97%E4%BD%93%E4%BC%9A/\",\"title\":\"心得体会 分类\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"心得体会 分类\",\"blog\":{\"type\":\"category\",\"name\":\"心得体会\",\"key\":\"category\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
