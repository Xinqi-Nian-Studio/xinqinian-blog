import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/category/开发工具/index.html.vue"
const data = JSON.parse("{\"path\":\"/category/%E5%BC%80%E5%8F%91%E5%B7%A5%E5%85%B7/\",\"title\":\"开发工具 分类\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"开发工具 分类\",\"blog\":{\"type\":\"category\",\"name\":\"开发工具\",\"key\":\"category\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
