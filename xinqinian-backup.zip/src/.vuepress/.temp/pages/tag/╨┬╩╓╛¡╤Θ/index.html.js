import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/新手经验/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/%E6%96%B0%E6%89%8B%E7%BB%8F%E9%AA%8C/\",\"title\":\"标签: 新手经验\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: 新手经验\",\"blog\":{\"type\":\"category\",\"name\":\"新手经验\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
