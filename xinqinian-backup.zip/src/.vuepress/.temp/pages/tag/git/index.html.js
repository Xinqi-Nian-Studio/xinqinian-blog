import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/git/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/git/\",\"title\":\"标签: Git\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: Git\",\"blog\":{\"type\":\"category\",\"name\":\"Git\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
