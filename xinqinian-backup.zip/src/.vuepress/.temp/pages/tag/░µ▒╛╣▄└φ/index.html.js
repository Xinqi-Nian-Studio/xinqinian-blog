import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/版本管理/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/%E7%89%88%E6%9C%AC%E7%AE%A1%E7%90%86/\",\"title\":\"标签: 版本管理\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: 版本管理\",\"blog\":{\"type\":\"category\",\"name\":\"版本管理\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
