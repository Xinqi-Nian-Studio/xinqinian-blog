import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/c_/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/c_/\",\"title\":\"标签: C#\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: C#\",\"blog\":{\"type\":\"category\",\"name\":\"C#\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
