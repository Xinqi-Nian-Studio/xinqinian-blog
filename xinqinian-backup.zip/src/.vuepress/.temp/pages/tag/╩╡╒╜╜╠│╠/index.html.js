import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/实战教程/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/%E5%AE%9E%E6%88%98%E6%95%99%E7%A8%8B/\",\"title\":\"标签: 实战教程\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: 实战教程\",\"blog\":{\"type\":\"category\",\"name\":\"实战教程\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
