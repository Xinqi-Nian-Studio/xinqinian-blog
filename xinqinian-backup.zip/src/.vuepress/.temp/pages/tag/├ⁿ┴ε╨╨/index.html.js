import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/命令行/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/%E5%91%BD%E4%BB%A4%E8%A1%8C/\",\"title\":\"标签: 命令行\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: 命令行\",\"blog\":{\"type\":\"category\",\"name\":\"命令行\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
