import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/pr/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/pr/\",\"title\":\"标签: PR\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: PR\",\"blog\":{\"type\":\"category\",\"name\":\"PR\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
