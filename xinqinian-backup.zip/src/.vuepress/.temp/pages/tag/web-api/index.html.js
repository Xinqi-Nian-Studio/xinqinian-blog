import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/web-api/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/web-api/\",\"title\":\"标签: Web API\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: Web API\",\"blog\":{\"type\":\"category\",\"name\":\"Web API\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
