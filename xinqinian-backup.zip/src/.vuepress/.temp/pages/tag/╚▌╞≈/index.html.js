import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/容器/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/%E5%AE%B9%E5%99%A8/\",\"title\":\"标签: 容器\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: 容器\",\"blog\":{\"type\":\"category\",\"name\":\"容器\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
