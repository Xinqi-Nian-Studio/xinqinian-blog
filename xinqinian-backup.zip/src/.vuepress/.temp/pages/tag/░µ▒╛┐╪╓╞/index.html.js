import comp from "F:/xinqinian-backup/src/.vuepress/.temp/pages/tag/版本控制/index.html.vue"
const data = JSON.parse("{\"path\":\"/tag/%E7%89%88%E6%9C%AC%E6%8E%A7%E5%88%B6/\",\"title\":\"标签: 版本控制\",\"lang\":\"zh-CN\",\"frontmatter\":{\"dir\":{\"index\":false},\"index\":false,\"feed\":false,\"sitemap\":false,\"title\":\"标签: 版本控制\",\"blog\":{\"type\":\"category\",\"name\":\"版本控制\",\"key\":\"tag\"},\"layout\":\"Blog\"},\"git\":{},\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\"}")
export { comp, data }
