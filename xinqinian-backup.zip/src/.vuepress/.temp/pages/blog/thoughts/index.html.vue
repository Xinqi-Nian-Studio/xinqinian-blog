<template><div><p>##本篇文档仅为测试</p>
<h2 id="激动时刻" tabindex="-1"><a class="header-anchor" href="#激动时刻"><span>激动时刻</span></a></h2>
<p>昨晚睡前看了一眼GitHub，发现维护者回复了：</p>
<blockquote>
<p>LGTM! 🎉 Thanks for your contribution!</p>
</blockquote>
<p>我的第一个开源PR终于合并了！</p>
<h2 id="几点感悟" tabindex="-1"><a class="header-anchor" href="#几点感悟"><span>几点感悟</span></a></h2>
<p><strong>1. 从小处着手</strong>
不要一上来就想改核心代码。我这次只是修正了一个文档链接，全程没写一行代码。</p>
<p><strong>2. 多看closed PR</strong>
发现这个项目有专门的“good first issue”标签，挑了个文档任务练手。</p>
<p><strong>3. 耐心等待</strong>
从提交到合并用了两周。期间还被要求改了一次格式，别着急，维护者也是用爱发电。</p>
<h2 id="下一步" tabindex="-1"><a class="header-anchor" href="#下一步"><span>下一步</span></a></h2>
<p>下周打算试试修复一个简单的CSS样式问题，继续在这个项目里混脸熟。</p>
<hr>
<p><em>写得不好没关系，先迈出第一步。</em></p>
</div></template>


