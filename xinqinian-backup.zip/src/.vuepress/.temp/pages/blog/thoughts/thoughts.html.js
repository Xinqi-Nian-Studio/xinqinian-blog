import comp from "F:/Xinqi-Nian-Studio/src/.vuepress/.temp/pages/blog/thoughts/thoughts.html.vue"
const data = JSON.parse("{\"path\":\"/blog/thoughts/thoughts.html\",\"title\":\"心得体会\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":0.17,\"words\":52},\"filePathRelative\":\"blog/thoughts/thoughts.md\",\"excerpt\":\"\\n<blockquote>\\n<p>技术之路，始于足下。</p>\\n</blockquote>\\n<p>这里记录我们在技术学习、项目开发和个人成长中的思考与感悟。</p>\\n<p>但是我们才注册，暂时还没有呢</p>\\n\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
