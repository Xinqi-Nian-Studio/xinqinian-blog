export const store = JSON.parse("[\"/blog/backend/\",\"/blog/devtools/\",\"/blog/frontend/\",\"/blog/frontend/test-vue3-article.html\"]");
