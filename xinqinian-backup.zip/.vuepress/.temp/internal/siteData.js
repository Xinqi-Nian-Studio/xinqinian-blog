export const siteData = JSON.parse("{\"base\":\"/\",\"lang\":\"zh-CN\",\"title\":\"新启年科技工作室\",\"description\":\"一群热爱技术、喜欢折腾的伙伴组成的非商业、纯兴趣团队\",\"head\":[[\"link\",{\"rel\":\"stylesheet\",\"href\":\"https://unpkg.com/@fortawesome/fontawesome-free@6.4.0/css/all.min.css\"}],[\"link\",{\"rel\":\"icon\",\"href\":\"/favicon.ico\"}],[\"meta\",{\"name\":\"keywords\",\"content\":\"新启年,科技工作室,技术团队,开源项目,技术博客\"}],[\"meta\",{\"name\":\"author\",\"content\":\"新启年科技工作室\"}],[\"meta\",{\"name\":\"viewport\",\"content\":\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\"}]],\"locales\":{}}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateSiteData) {
    __VUE_HMR_RUNTIME__.updateSiteData(siteData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ siteData }) => {
    __VUE_HMR_RUNTIME__.updateSiteData(siteData)
  })
}
