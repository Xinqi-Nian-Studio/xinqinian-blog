export const redirects = JSON.parse("{}")

export const routes = Object.fromEntries([
  ["/about.html", { loader: () => import(/* webpackChunkName: "about.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/about.html.js"), meta: {"title":"关于我们"} }],
  ["/", { loader: () => import(/* webpackChunkName: "index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/index.html.js"), meta: {"title":"博客主页","icon":"house"} }],
  ["/blog/", { loader: () => import(/* webpackChunkName: "blog_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/blog/index.html.js"), meta: {"title":"技术博客"} }],
  ["/blog/thoughts.html", { loader: () => import(/* webpackChunkName: "blog_thoughts.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/blog/thoughts.html.js"), meta: {"title":""} }],
  ["/projects/", { loader: () => import(/* webpackChunkName: "projects_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/projects/index.html.js"), meta: {"title":"项目展示"} }],
  ["/team/conventions.html", { loader: () => import(/* webpackChunkName: "team_conventions.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/conventions.html.js"), meta: {"title":"协作规范"} }],
  ["/team/members.html", { loader: () => import(/* webpackChunkName: "team_members.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/members.html.js"), meta: {"title":"团队成员"} }],
  ["/team/", { loader: () => import(/* webpackChunkName: "team_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/index.html.js"), meta: {"title":"团队"} }],
  ["/team/share-sessions.html", { loader: () => import(/* webpackChunkName: "team_share-sessions.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/share-sessions.html.js"), meta: {"title":"技术分享会"} }],
  ["/team/workflow.html", { loader: () => import(/* webpackChunkName: "team_workflow.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/workflow.html.js"), meta: {"title":"工作流程"} }],
  ["/blog/backend/", { loader: () => import(/* webpackChunkName: "blog_backend_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/blog/backend/index.html.js"), meta: {"title":"","type":"article"} }],
  ["/blog/devtools/", { loader: () => import(/* webpackChunkName: "blog_devtools_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/blog/devtools/index.html.js"), meta: {"title":"","type":"article"} }],
  ["/blog/frontend/", { loader: () => import(/* webpackChunkName: "blog_frontend_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/blog/frontend/index.html.js"), meta: {"excerpt":"\n<p>这里记录前端技术的学习笔记、实践经验和解决方案。</p>\n<h2>主要内容</h2>\n<h3>框架与库</h3>\n<ul>\n<li>Vue 3 全家桶实战记录</li>\n<li>React Hooks 与状态管理</li>\n<li>小程序开发技巧与优化</li>\n</ul>\n<h3>样式与交互</h3>\n<ul>\n<li>CSS 现代布局方案</li>\n<li>动画实现与性能优化</li>\n<li>响应式设计适配实践</li>\n</ul>\n<h3>工程化</h3>\n<ul>\n<li>构建工具配置与优化</li>\n<li>代码质量与团队规范</li>\n<li>部署流程与性能监控</li>\n</ul>","readingTime":{"minutes":0.84,"words":253},"title":"前端开发","type":"article"} }],
  ["/blog/frontend/test-vue3-article.html", { loader: () => import(/* webpackChunkName: "blog_frontend_test-vue3-article.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/blog/frontend/test-vue3-article.html.js"), meta: {"excerpt":"\n<h2>cat &gt; blog/frontend/vue3-guide.md &lt;&lt; 'EOF'</h2>\n<p>title: \"Vue 3 入门指南\"\ndate: 2024-05-15\ncategory: \"前端开发\"\ntag:</p>\n<ul>\n<li>Vue3</li>\n<li>前端框架</li>\n<li>教程</li>\n</ul>\n<hr>\n<h1>Vue 3 入门指南</h1>\n<p>Vue 3 带来了许多新特性和改进...</p>\n<h2>Composition API</h2>\n<div class=\"language-javascript line-numbers-mode\" data-highlighter=\"shiki\" data-ext=\"javascript\" style=\"--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34\"><pre class=\"shiki shiki-themes one-light one-dark-pro vp-code\"><code class=\"language-javascript\"><span class=\"line\"><span style=\"--shiki-light:#A626A4;--shiki-dark:#C678DD\">import</span><span style=\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\"> { </span><span style=\"--shiki-light:#E45649;--shiki-dark:#E06C75\">ref</span><span style=\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\">, </span><span style=\"--shiki-light:#E45649;--shiki-dark:#E06C75\">computed</span><span style=\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\"> } </span><span style=\"--shiki-light:#A626A4;--shiki-dark:#C678DD\">from</span><span style=\"--shiki-light:#50A14F;--shiki-dark:#98C379\"> 'vue'</span></span>\n<span class=\"line\"></span>\n<span class=\"line\"><span style=\"--shiki-light:#A626A4;--shiki-dark:#C678DD\">const</span><span style=\"--shiki-light:#986801;--shiki-dark:#E5C07B\"> count</span><span style=\"--shiki-light:#0184BC;--shiki-dark:#56B6C2\"> =</span><span style=\"--shiki-light:#4078F2;--shiki-dark:#61AFEF\"> ref</span><span style=\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\">(</span><span style=\"--shiki-light:#986801;--shiki-dark:#D19A66\">0</span><span style=\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\">)</span></span>\n<span class=\"line\"><span style=\"--shiki-light:#A626A4;--shiki-dark:#C678DD\">const</span><span style=\"--shiki-light:#986801;--shiki-dark:#E5C07B\"> double</span><span style=\"--shiki-light:#0184BC;--shiki-dark:#56B6C2\"> =</span><span style=\"--shiki-light:#4078F2;--shiki-dark:#61AFEF\"> computed</span><span style=\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\">(() </span><span style=\"--shiki-light:#A626A4;--shiki-dark:#C678DD\">=&gt;</span><span style=\"--shiki-light:#383A42;--shiki-dark:#E5C07B\"> count</span><span style=\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\">.</span><span style=\"--shiki-light:#E45649;--shiki-dark:#E06C75\">value</span><span style=\"--shiki-light:#0184BC;--shiki-dark:#56B6C2\"> *</span><span style=\"--shiki-light:#986801;--shiki-dark:#D19A66\"> 2</span><span style=\"--shiki-light:#383A42;--shiki-dark:#ABB2BF\">)</span></span></code></pre>\n<div class=\"line-numbers\" aria-hidden=\"true\" style=\"counter-reset:line-number 0\"><div class=\"line-number\"></div><div class=\"line-number\"></div><div class=\"line-number\"></div><div class=\"line-number\"></div></div></div>","readingTime":{"minutes":0.24,"words":72},"title":"创建测试文章 1","type":"article"} }],
  ["/projects/frameworks/", { loader: () => import(/* webpackChunkName: "projects_frameworks_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/projects/frameworks/index.html.js"), meta: {"title":"技术实践"} }],
  ["/projects/resources/", { loader: () => import(/* webpackChunkName: "projects_resources_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/projects/resources/index.html.js"), meta: {"title":"学习资源"} }],
  ["/projects/tools/", { loader: () => import(/* webpackChunkName: "projects_tools_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/projects/tools/index.html.js"), meta: {"title":"开发工具"} }],
  ["/404.html", { loader: () => import(/* webpackChunkName: "404.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/404.html.js"), meta: {"title":""} }],
  ["/category/", { loader: () => import(/* webpackChunkName: "category_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/category/index.html.js"), meta: {"title":"分类","index":false} }],
  ["/tag/", { loader: () => import(/* webpackChunkName: "tag_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/tag/index.html.js"), meta: {"title":"标签","index":false} }],
  ["/article/", { loader: () => import(/* webpackChunkName: "article_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/article/index.html.js"), meta: {"title":"文章","index":false} }],
  ["/star/", { loader: () => import(/* webpackChunkName: "star_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/star/index.html.js"), meta: {"title":"星标","index":false} }],
  ["/timeline/", { loader: () => import(/* webpackChunkName: "timeline_index.html" */"F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/timeline/index.html.js"), meta: {"title":"时间轴","index":false} }],
]);

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateRoutes) {
    __VUE_HMR_RUNTIME__.updateRoutes(routes)
  }
  if (__VUE_HMR_RUNTIME__.updateRedirects) {
    __VUE_HMR_RUNTIME__.updateRedirects(redirects)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ routes, redirects }) => {
    __VUE_HMR_RUNTIME__.updateRoutes(routes)
    __VUE_HMR_RUNTIME__.updateRedirects(redirects)
  })
}
