import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/about.html.vue"
const data = JSON.parse("{\"path\":\"/about.html\",\"title\":\"关于我们\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":1.34,\"words\":402},\"filePathRelative\":\"about.md\",\"excerpt\":\"\\n<h2>我们是谁</h2>\\n<p>新启年科技工作室，是一群纯粹因为喜欢技术而聚在一起的伙伴。</p>\\n<p>没有商业目标，不做业绩考核，不接外包项目。这里就是大家<strong>一起写代码、做项目、学技术、分享心得</strong>的地方。</p>\\n<h2>怎么运转</h2>\\n<h3>分组协作</h3>\\n<p>我们有六个小组，各司其职：</p>\\n<ul>\\n<li><strong>A组 网站管理部</strong>：维护我们的论坛和网站</li>\\n<li><strong>B组 开发部</strong>：负责各种应用的开发和实践</li>\\n<li><strong>C组 宣传部</strong>：记录和分享我们的项目与成果</li>\\n<li><strong>D组 客服部</strong>：帮助新成员融入，解答日常问题</li>\\n<li><strong>E组 资源部</strong>：为项目寻找所需的素材、工具或学习资源</li>\\n<li><strong>F组 策划部</strong>：组织会议，协调大家想做的事情</li>\\n</ul>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
