import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/projects/tools/index.html.vue"
const data = JSON.parse("{\"path\":\"/projects/tools/\",\"title\":\"开发工具\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":0.87,\"words\":260},\"filePathRelative\":\"projects/tools/README.md\",\"excerpt\":\"\\n<p>这里集合了我们开发过程中创建或整理的实用工具，旨在提升开发效率与工作流体验。</p>\\n<h2>工具类型</h2>\\n<h3>效率脚本</h3>\\n<p>自动化重复任务的脚本，涵盖部署、构建、文件处理等场景。</p>\\n<h3>开发者工具</h3>\\n<p>辅助编码、调试、测试的实用程序与插件。</p>\\n<h3>配置模板</h3>\\n<p>经过优化的项目配置、环境设置与工作流模板。</p>\\n<h2>使用说明</h2>\\n<p>每个工具都包含：</p>\\n<ul>\\n<li><strong>功能说明</strong>：解决什么问题</li>\\n<li><strong>使用方法</strong>：如何安装与使用</li>\\n<li><strong>适用场景</strong>：推荐的使用情境</li>\\n<li><strong>技术细节</strong>：实现原理与自定义选项</li>\\n</ul>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
