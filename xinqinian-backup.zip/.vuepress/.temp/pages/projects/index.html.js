import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/projects/index.html.vue"
const data = JSON.parse("{\"path\":\"/projects/\",\"title\":\"项目展示\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":0.79,\"words\":237},\"filePathRelative\":\"projects/README.md\",\"excerpt\":\"\\n<p>这里展示新启年工作室的技术项目与成果。</p>\\n<h2>项目分类</h2>\\n<h3>开发工具</h3>\\n<p>实用的软件工具、效率脚本与开发者辅助程序。</p>\\n<h3>技术实践</h3>\\n<p>对新技术的探索、框架实验与学习型项目。</p>\\n<h3>资源整理</h3>\\n<p>经过验证的学习资料、教程与实用资源集合。</p>\\n<h2>项目特色</h2>\\n<ul>\\n<li><strong>实用导向</strong>：每个项目都解决明确的技术或效率问题</li>\\n<li><strong>代码开源</strong>：所有项目均开放源代码，可自由使用与学习</li>\\n<li><strong>持续维护</strong>：活跃项目定期更新，确保可用性</li>\\n<li><strong>文档完整</strong>：提供清晰的使用说明和技术实现介绍</li>\\n</ul>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
