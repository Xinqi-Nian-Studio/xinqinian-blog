<template><div><h1 id="项目展示" tabindex="-1"><a class="header-anchor" href="#项目展示"><span>项目展示</span></a></h1>
<p>这里展示新启年工作室的技术项目与成果。</p>
<h2 id="项目分类" tabindex="-1"><a class="header-anchor" href="#项目分类"><span>项目分类</span></a></h2>
<h3 id="开发工具" tabindex="-1"><a class="header-anchor" href="#开发工具"><span>开发工具</span></a></h3>
<p>实用的软件工具、效率脚本与开发者辅助程序。</p>
<h3 id="技术实践" tabindex="-1"><a class="header-anchor" href="#技术实践"><span>技术实践</span></a></h3>
<p>对新技术的探索、框架实验与学习型项目。</p>
<h3 id="资源整理" tabindex="-1"><a class="header-anchor" href="#资源整理"><span>资源整理</span></a></h3>
<p>经过验证的学习资料、教程与实用资源集合。</p>
<h2 id="项目特色" tabindex="-1"><a class="header-anchor" href="#项目特色"><span>项目特色</span></a></h2>
<ul>
<li><strong>实用导向</strong>：每个项目都解决明确的技术或效率问题</li>
<li><strong>代码开源</strong>：所有项目均开放源代码，可自由使用与学习</li>
<li><strong>持续维护</strong>：活跃项目定期更新，确保可用性</li>
<li><strong>文档完整</strong>：提供清晰的使用说明和技术实现介绍</li>
</ul>
<h2 id="技术栈" tabindex="-1"><a class="header-anchor" href="#技术栈"><span>技术栈</span></a></h2>
<p>我们的项目涵盖多种技术方向：</p>
<ul>
<li>前端：Vue、React、TypeScript</li>
<li>后端：Python、Java、.NET、Node.js</li>
<li>移动端：小程序、Flutter</li>
<li>工具链：Vite、Webpack、Docker</li>
</ul>
<hr>
<blockquote>
<p>💡 所有项目均可在GitHub找到源码。欢迎技术交流与反馈。</p>
</blockquote>
</div></template>


