import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/projects/frameworks/index.html.vue"
const data = JSON.parse("{\"path\":\"/projects/frameworks/\",\"title\":\"技术实践\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":0.95,\"words\":285},\"filePathRelative\":\"projects/frameworks/README.md\",\"excerpt\":\"\\n<p>这里是我们对新技术的探索与实践记录，包括框架研究、原型验证和技术方案测试。</p>\\n<h2>实践方向</h2>\\n<h3>前端框架</h3>\\n<ul>\\n<li>Vue 3 生态探索</li>\\n<li>React 新特性实践</li>\\n<li>小程序框架比较</li>\\n</ul>\\n<h3>后端架构</h3>\\n<ul>\\n<li>微服务架构原型</li>\\n<li>数据库技术对比</li>\\n<li>性能优化方案</li>\\n</ul>\\n<h3>开发范式</h3>\\n<ul>\\n<li>响应式编程实践</li>\\n<li>函数式编程应用</li>\\n<li>工程化方案验证</li>\\n</ul>\\n<h2>实践原则</h2>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
