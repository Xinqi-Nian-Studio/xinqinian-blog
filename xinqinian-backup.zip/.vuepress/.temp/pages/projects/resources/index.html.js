import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/projects/resources/index.html.vue"
const data = JSON.parse("{\"path\":\"/projects/resources/\",\"title\":\"学习资源\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":1,\"words\":300},\"filePathRelative\":\"projects/resources/README.md\",\"excerpt\":\"\\n<p>这里整理了经过我们实际使用验证的开发资源、学习材料和实用参考。</p>\\n<h2>资源类型</h2>\\n<h3>官方文档</h3>\\n<ul>\\n<li>重要技术栈的官方文档精读笔记</li>\\n<li>版本更新要点与迁移指南</li>\\n<li>官方最佳实践总结</li>\\n</ul>\\n<h3>教程指南</h3>\\n<ul>\\n<li>分步式学习教程与路径建议</li>\\n<li>常见问题解决方案集合</li>\\n<li>实战项目完整实现过程</li>\\n</ul>\\n<h3>工具集合</h3>\\n<ul>\\n<li>开发效率工具推荐与配置</li>\\n<li>设计资源与素材库</li>\\n<li>开发环境配置清单</li>\\n</ul>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
