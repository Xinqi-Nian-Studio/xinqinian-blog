import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/blog/index.html.vue"
const data = JSON.parse("{\"path\":\"/blog/\",\"title\":\"技术博客\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":0.47,\"words\":140},\"filePathRelative\":\"blog/README.md\",\"excerpt\":\"\\n<p>这里记录新启年工作室在技术实践中的探索与思考。</p>\\n<h2>文章分类</h2>\\n<h3>前端开发</h3>\\n<p>关于 Vue、React、小程序等前端技术的实践记录和解决方案。</p>\\n<h3>后端开发</h3>\\n<p>涵盖 .NET、Python、Java、C++ 等后端技术的应用经验和架构思考。</p>\\n<h3>开发工具</h3>\\n<p>分享提升开发效率的工具、配置和工作流方法。</p>\\n<h3>心得体会</h3>\\n<p>技术路上的感悟、项目经验总结和非纯技术类的思考分享。</p>\\n<hr>\\n<blockquote>\\n<p>技术之路，与君共勉。</p>\\n</blockquote>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
