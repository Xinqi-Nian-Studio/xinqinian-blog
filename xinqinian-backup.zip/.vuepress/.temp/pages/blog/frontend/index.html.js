import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/blog/frontend/index.html.vue"
const data = JSON.parse("{\"path\":\"/blog/frontend/\",\"title\":\"前端开发\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":0.84,\"words\":253},\"filePathRelative\":\"blog/frontend/README.md\",\"excerpt\":\"\\n<p>这里记录前端技术的学习笔记、实践经验和解决方案。</p>\\n<h2>主要内容</h2>\\n<h3>框架与库</h3>\\n<ul>\\n<li>Vue 3 全家桶实战记录</li>\\n<li>React Hooks 与状态管理</li>\\n<li>小程序开发技巧与优化</li>\\n</ul>\\n<h3>样式与交互</h3>\\n<ul>\\n<li>CSS 现代布局方案</li>\\n<li>动画实现与性能优化</li>\\n<li>响应式设计适配实践</li>\\n</ul>\\n<h3>工程化</h3>\\n<ul>\\n<li>构建工具配置与优化</li>\\n<li>代码质量与团队规范</li>\\n<li>部署流程与性能监控</li>\\n</ul>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
