<template><div><h1 id="关于我们" tabindex="-1"><a class="header-anchor" href="#关于我们"><span>关于我们</span></a></h1>
<h2 id="我们是谁" tabindex="-1"><a class="header-anchor" href="#我们是谁"><span>我们是谁</span></a></h2>
<p>新启年科技工作室，是一群纯粹因为喜欢技术而聚在一起的伙伴。</p>
<p>没有商业目标，不做业绩考核，不接外包项目。这里就是大家<strong>一起写代码、做项目、学技术、分享心得</strong>的地方。</p>
<h2 id="怎么运转" tabindex="-1"><a class="header-anchor" href="#怎么运转"><span>怎么运转</span></a></h2>
<h3 id="分组协作" tabindex="-1"><a class="header-anchor" href="#分组协作"><span>分组协作</span></a></h3>
<p>我们有六个小组，各司其职：</p>
<ul>
<li><strong>A组 网站管理部</strong>：维护我们的论坛和网站</li>
<li><strong>B组 开发部</strong>：负责各种应用的开发和实践</li>
<li><strong>C组 宣传部</strong>：记录和分享我们的项目与成果</li>
<li><strong>D组 客服部</strong>：帮助新成员融入，解答日常问题</li>
<li><strong>E组 资源部</strong>：为项目寻找所需的素材、工具或学习资源</li>
<li><strong>F组 策划部</strong>：组织会议，协调大家想做的事情</li>
</ul>
<h3 id="日常活动" tabindex="-1"><a class="header-anchor" href="#日常活动"><span>日常活动</span></a></h3>
<ul>
<li><strong>在QQ群里聊天</strong>：随时讨论技术问题、分享新鲜事</li>
<li><strong>做自己感兴趣的项目</strong>：自己发起，或参与别人的项目</li>
<li><strong>定期开会</strong>：聊聊进度，同步信息</li>
<li><strong>技术分享</strong>：谁有心得，谁就来群里讲讲</li>
</ul>
<h2 id="加入我们" tabindex="-1"><a class="header-anchor" href="#加入我们"><span>加入我们</span></a></h2>
<p>如果你：</p>
<ul>
<li>对技术有热情，愿意动手尝试</li>
<li>喜欢分享，也乐意向别人学习</li>
<li>想要一个能一起写代码、聊技术的环境</li>
</ul>
<p>那么，欢迎你。</p>
<p><strong>我们看重的是热情和参与，不是水平高低。</strong></p>
<h2 id="我们的认识" tabindex="-1"><a class="header-anchor" href="#我们的认识"><span>我们的认识</span></a></h2>
<p>技术是件快乐的事。在这里，它应该保持这种快乐。</p>
<p>一切都很简单：因为兴趣而开始，在协作中学习，在分享里收获。</p>
<p>这就是新启年。</p>
</div></template>


