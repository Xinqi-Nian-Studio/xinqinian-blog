import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/intro.html.vue"
const data = JSON.parse("{\"path\":\"/intro.html\",\"title\":\"介绍页\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"circle-info\",\"cover\":\"/assets/images/cover3.jpg\",\"description\":\"介绍页 新启年科技工作室是一支专注软件开发与数字解决方案的技术团队。我们擅长网站搭建、小程序开发、系统定制与工具制作，坚持以技术解决实际问题。无论是个人项目、校园需求还是企业数字化，我们都提供清晰透明的全流程服务，确保每个项目扎实落地、可靠交付。 我们以“新起点、新突破”为理念，用代码助力每一次成长。团队虽小，但流程严谨、交付完整——从需求分析到技术方...\",\"head\":[[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"介绍页\\\",\\\"image\\\":[\\\"https://mister-hope.github.io/assets/images/cover3.jpg\\\"],\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"新启年工作室\\\",\\\"url\\\":\\\"https://mister-hope.com\\\"}]}\"],[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/intro.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"新启年科技工作室\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"介绍页\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"介绍页 新启年科技工作室是一支专注软件开发与数字解决方案的技术团队。我们擅长网站搭建、小程序开发、系统定制与工具制作，坚持以技术解决实际问题。无论是个人项目、校园需求还是企业数字化，我们都提供清晰透明的全流程服务，确保每个项目扎实落地、可靠交付。 我们以“新起点、新突破”为理念，用代码助力每一次成长。团队虽小，但流程严谨、交付完整——从需求分析到技术方...\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:image\",\"content\":\"https://mister-hope.github.io/assets/images/cover3.jpg\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"name\":\"twitter:card\",\"content\":\"summary_large_image\"}],[\"meta\",{\"name\":\"twitter:image:src\",\"content\":\"https://mister-hope.github.io/assets/images/cover3.jpg\"}],[\"meta\",{\"name\":\"twitter:image:alt\",\"content\":\"介绍页\"}]]},\"readingTime\":{\"minutes\":0.7,\"words\":211},\"filePathRelative\":\"intro.md\",\"excerpt\":\"\\n<p>新启年科技工作室是一支专注软件开发与数字解决方案的技术团队。我们擅长网站搭建、小程序开发、系统定制与工具制作，坚持以技术解决实际问题。无论是个人项目、校园需求还是企业数字化，我们都提供清晰透明的全流程服务，确保每个项目扎实落地、可靠交付。</p>\\n<p>我们以“新起点、新突破”为理念，用代码助力每一次成长。团队虽小，但流程严谨、交付完整——从需求分析到技术方案，从迭代开发到售后支持，全程保持沟通透明，并提供源代码、技术文档与部署指南。技术是我们的根基，务实是我们的态度。</p>\\n\",\"autoDesc\":true}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
