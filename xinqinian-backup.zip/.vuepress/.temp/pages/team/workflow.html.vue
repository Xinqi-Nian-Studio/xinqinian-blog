<template><div><h1 id="工作流程" tabindex="-1"><a class="header-anchor" href="#工作流程"><span>工作流程</span></a></h1>
<h2 id="项目流程" tabindex="-1"><a class="header-anchor" href="#项目流程"><span>项目流程</span></a></h2>
<h3 id="_1-想法收集" tabindex="-1"><a class="header-anchor" href="#_1-想法收集"><span>1. 想法收集</span></a></h3>
<ul>
<li><strong>渠道</strong>：微信群、论坛置顶帖</li>
<li><strong>格式</strong>：简单说明做什么、为什么做、谁来用</li>
<li><strong>收集人</strong>：F组</li>
</ul>
<h3 id="_2-会议讨论" tabindex="-1"><a class="header-anchor" href="#_2-会议讨论"><span>2. 会议讨论</span></a></h3>
<ul>
<li><strong>组织</strong>：F组（策划部）负责安排</li>
<li><strong>时间</strong>：每周一次，线上会议</li>
<li><strong>内容</strong>：
<ol>
<li>新提案初筛</li>
<li>进行中项目进度同步</li>
<li>遇到的问题协调</li>
</ol>
</li>
</ul>
<h3 id="_3-开发实施" tabindex="-1"><a class="header-anchor" href="#_3-开发实施"><span>3. 开发实施</span></a></h3>
<div class="language- line-numbers-mode" data-highlighter="shiki" data-ext="" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-"><span class="line"><span>认领任务 → 开发测试 → 内部演示 → 收集反馈 → 优化发布</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div><ul>
<li><strong>任务板</strong>：GitHub Projects 或看板工具</li>
<li><strong>代码管理</strong>：分支开发，PR合并</li>
<li><strong>测试</strong>：至少一位其他成员验证</li>
</ul>
<h2 id="协作规范" tabindex="-1"><a class="header-anchor" href="#协作规范"><span>协作规范</span></a></h2>
<h3 id="沟通方式" tabindex="-1"><a class="header-anchor" href="#沟通方式"><span>沟通方式</span></a></h3>
<ul>
<li><strong>日常</strong>：微信群即时沟通</li>
<li><strong>文档</strong>：项目README必填</li>
<li><strong>周报</strong>：简要说明本周完成、下周计划</li>
</ul>
<h3 id="资源申请" tabindex="-1"><a class="header-anchor" href="#资源申请"><span>资源申请</span></a></h3>
<p>需要设计素材、服务器资源等，直接联系E组（资源部）。</p>
<h3 id="发布宣传" tabindex="-1"><a class="header-anchor" href="#发布宣传"><span>发布宣传</span></a></h3>
<p>项目完成后，由C组（宣传部）制作介绍内容并发布。</p>
</div></template>


