import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/members.html.vue"
const data = JSON.parse("{\"path\":\"/team/members.html\",\"title\":\"团队成员\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":1.08,\"words\":325},\"filePathRelative\":\"team/members.md\",\"excerpt\":\"\\n<h2>🏢 组织架构</h2>\\n<h3>A组 - 网站管理部</h3>\\n<p><strong>职责</strong>：论坛管理与网站维护<br>\\n<strong>状态</strong>：满员 ✅</p>\\n<table>\\n<thead>\\n<tr>\\n<th>角色</th>\\n<th>成员</th>\\n</tr>\\n</thead>\\n<tbody>\\n<tr>\\n<td>组长</td>\\n<td>Creepy_Nightmares</td>\\n</tr>\\n<tr>\\n<td>组员</td>\\n<td>emulate/0</td>\\n</tr>\\n<tr>\\n<td>组员</td>\\n<td>喵~</td>\\n</tr>\\n<tr>\\n<td>组员</td>\\n<td>wangzichang</td>\\n</tr>\\n</tbody>\\n</table>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
