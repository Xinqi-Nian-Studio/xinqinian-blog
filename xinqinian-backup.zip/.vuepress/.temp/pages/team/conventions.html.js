import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/conventions.html.vue"
const data = JSON.parse("{\"path\":\"/team/conventions.html\",\"title\":\"协作规范\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":1.81,\"words\":543},\"filePathRelative\":\"team/conventions.md\",\"excerpt\":\"\\n<h2>🗣️ 沟通约定</h2>\\n<h3>日常交流</h3>\\n<ul>\\n<li><strong>微信群</strong>：用于即时讨论、问题求助</li>\\n<li><strong>论坛</strong>：重要通知、技术分享、会议纪要归档</li>\\n<li><strong>邮件</strong>：正式申请、对外联络（可选）</li>\\n</ul>\\n<h3>称呼与态度</h3>\\n<ul>\\n<li>互称昵称或用户名，随意自然</li>\\n<li>技术讨论对事不对人</li>\\n<li>遇到问题先查文档，再提问</li>\\n</ul>\\n<h2>💻 开发规范</h2>\\n<h3>代码管理</h3>\\n<div class=\\\"language- line-numbers-mode\\\" data-highlighter=\\\"shiki\\\" data-ext=\\\"\\\" style=\\\"--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34\\\"><pre class=\\\"shiki shiki-themes one-light one-dark-pro vp-code\\\"><code class=\\\"language-\\\"><span class=\\\"line\\\"><span>分支命名：</span></span>\\n<span class=\\\"line\\\"><span>- 功能：feature/简短描述</span></span>\\n<span class=\\\"line\\\"><span>- 修复：fix/问题描述</span></span>\\n<span class=\\\"line\\\"><span>- 文档：docs/更新内容</span></span>\\n<span class=\\\"line\\\"><span></span></span>\\n<span class=\\\"line\\\"><span>提交信息格式：</span></span>\\n<span class=\\\"line\\\"><span>类型(范围): 描述</span></span>\\n<span class=\\\"line\\\"><span>例：feat(auth): 增加登录验证</span></span></code></pre>\\n<div class=\\\"line-numbers\\\" aria-hidden=\\\"true\\\" style=\\\"counter-reset:line-number 0\\\"><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div></div></div>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
