<template><div><h1 id="协作规范" tabindex="-1"><a class="header-anchor" href="#协作规范"><span>协作规范</span></a></h1>
<h2 id="🗣️-沟通约定" tabindex="-1"><a class="header-anchor" href="#🗣️-沟通约定"><span>🗣️ 沟通约定</span></a></h2>
<h3 id="日常交流" tabindex="-1"><a class="header-anchor" href="#日常交流"><span>日常交流</span></a></h3>
<ul>
<li><strong>微信群</strong>：用于即时讨论、问题求助</li>
<li><strong>论坛</strong>：重要通知、技术分享、会议纪要归档</li>
<li><strong>邮件</strong>：正式申请、对外联络（可选）</li>
</ul>
<h3 id="称呼与态度" tabindex="-1"><a class="header-anchor" href="#称呼与态度"><span>称呼与态度</span></a></h3>
<ul>
<li>互称昵称或用户名，随意自然</li>
<li>技术讨论对事不对人</li>
<li>遇到问题先查文档，再提问</li>
</ul>
<h2 id="💻-开发规范" tabindex="-1"><a class="header-anchor" href="#💻-开发规范"><span>💻 开发规范</span></a></h2>
<h3 id="代码管理" tabindex="-1"><a class="header-anchor" href="#代码管理"><span>代码管理</span></a></h3>
<div class="language- line-numbers-mode" data-highlighter="shiki" data-ext="" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-"><span class="line"><span>分支命名：</span></span>
<span class="line"><span>- 功能：feature/简短描述</span></span>
<span class="line"><span>- 修复：fix/问题描述</span></span>
<span class="line"><span>- 文档：docs/更新内容</span></span>
<span class="line"><span></span></span>
<span class="line"><span>提交信息格式：</span></span>
<span class="line"><span>类型(范围): 描述</span></span>
<span class="line"><span>例：feat(auth): 增加登录验证</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="项目结构" tabindex="-1"><a class="header-anchor" href="#项目结构"><span>项目结构</span></a></h3>
<p>新项目应在根目录包含：</p>
<ul>
<li><code v-pre>README.md</code> - 项目说明、如何运行</li>
<li><code v-pre>docs/</code> - 详细文档（如有）</li>
<li><code v-pre>.gitignore</code> - 排除不必要的文件</li>
</ul>
<h2 id="📅-会议制度" tabindex="-1"><a class="header-anchor" href="#📅-会议制度"><span>📅 会议制度</span></a></h2>
<h3 id="周会-f组组织" tabindex="-1"><a class="header-anchor" href="#周会-f组组织"><span>周会（F组组织）</span></a></h3>
<ul>
<li><strong>时间</strong>：每周一次，具体时间群内投票确定</li>
<li><strong>时长</strong>：不超过1小时</li>
<li><strong>内容</strong>：
<ol>
<li>各项目进度同步（每人1-2分钟）</li>
<li>新提案讨论（如有）</li>
<li>问题协调</li>
</ol>
</li>
<li><strong>纪要</strong>：由当次会议指定成员记录，发至论坛</li>
</ul>
<h3 id="项目会" tabindex="-1"><a class="header-anchor" href="#项目会"><span>项目会</span></a></h3>
<ul>
<li>按需召开，由项目负责人组织</li>
<li>会前明确议题，控制时长</li>
</ul>
<h2 id="🎯-质量要求" tabindex="-1"><a class="header-anchor" href="#🎯-质量要求"><span>🎯 质量要求</span></a></h2>
<h3 id="文档" tabindex="-1"><a class="header-anchor" href="#文档"><span>文档</span></a></h3>
<ul>
<li>公开项目必须有<code v-pre>README</code></li>
<li>复杂功能应有使用说明</li>
<li>关键决策记录在案</li>
</ul>
<h3 id="代码" tabindex="-1"><a class="header-anchor" href="#代码"><span>代码</span></a></h3>
<ul>
<li>提交前自测基本功能</li>
<li>PR应有描述和测试说明</li>
<li>鼓励代码审查，但不是强制</li>
</ul>
<h2 id="🔄-加入与贡献" tabindex="-1"><a class="header-anchor" href="#🔄-加入与贡献"><span>🔄 加入与贡献</span></a></h2>
<h3 id="新成员引导-d组负责" tabindex="-1"><a class="header-anchor" href="#新成员引导-d组负责"><span>新成员引导（D组负责）</span></a></h3>
<ol>
<li>介绍群、论坛、GitHub组织</li>
<li>指引查看现有项目</li>
<li>协助选择首个任务</li>
</ol>
<h3 id="贡献流程" tabindex="-1"><a class="header-anchor" href="#贡献流程"><span>贡献流程</span></a></h3>
<div class="language- line-numbers-mode" data-highlighter="shiki" data-ext="" style="--shiki-light:#383A42;--shiki-dark:#abb2bf;--shiki-light-bg:#FAFAFA;--shiki-dark-bg:#282c34"><pre class="shiki shiki-themes one-light one-dark-pro vp-code" v-pre=""><code class="language-"><span class="line"><span>发现兴趣 → 群内表达意向 → 认领任务 → 开始贡献</span></span></code></pre>
<div class="line-numbers" aria-hidden="true" style="counter-reset:line-number 0"><div class="line-number"></div></div></div><ul>
<li>任何成员可直接在项目提Issue</li>
<li>开发任务向B组同步进度</li>
<li>设计/文案需求联系C组</li>
</ul>
<h2 id="⚠️-注意事项" tabindex="-1"><a class="header-anchor" href="#⚠️-注意事项"><span>⚠️ 注意事项</span></a></h2>
<ol>
<li><strong>尊重时间</strong>：非紧急问题避免深夜@所有人</li>
<li><strong>主动沟通</strong>：遇到阻塞及时提出，不必硬撑</li>
<li><strong>保持学习</strong>：技术选型以适用为先，鼓励尝试</li>
<li><strong>享受过程</strong>：这是兴趣团体，别让协作成为负担</li>
</ol>
<hr>
<p><em>最后更新：2026年2月 · 本规范随团队发展调整</em></p>
</div></template>


