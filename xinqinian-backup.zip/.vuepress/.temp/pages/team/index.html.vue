<template><div><h1 id="团队" tabindex="-1"><a class="header-anchor" href="#团队"><span>团队</span></a></h1>
<p>这里是新启年工作室的团队协作相关信息。</p>
<h2 id="团队成员" tabindex="-1"><a class="header-anchor" href="#团队成员"><span>团队成员</span></a></h2>
<p>了解我们的成员组成和各小组职能。工作室根据职能分为不同小组，共同协作完成项目。</p>
<p><a href="./members">查看完整成员列表 →</a></p>
<h2 id="工作方式" tabindex="-1"><a class="header-anchor" href="#工作方式"><span>工作方式</span></a></h2>
<p>了解我们如何协作、沟通和推进项目。包括日常交流规范、会议制度和开发流程等。</p>
<ul>
<li><a href="./workflow">工作流程</a> - 项目从想法到落地的完整流程</li>
<li><a href="./conventions">协作规范</a> - 日常沟通与开发约定</li>
<li><a href="./share-sessions">技术分享</a> - 定期与随时的技术交流</li>
</ul>
<h2 id="合作与交流" tabindex="-1"><a class="header-anchor" href="#合作与交流"><span>合作与交流</span></a></h2>
<p>我们保持开放的交流态度：</p>
<ul>
<li><strong>技术讨论</strong>：欢迎就具体技术问题深入交流</li>
<li><strong>项目反馈</strong>：对我们公开项目的建议与意见</li>
<li><strong>经验分享</strong>：相互学习，共同成长</li>
</ul>
<hr>
<blockquote>
<p>一个人可以走得很快，一群人才能走得更远。技术之路，结伴而行。</p>
</blockquote>
</div></template>


