import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/workflow.html.vue"
const data = JSON.parse("{\"path\":\"/team/workflow.html\",\"title\":\"工作流程\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":0.8,\"words\":241},\"filePathRelative\":\"team/workflow.md\",\"excerpt\":\"\\n<h2>项目流程</h2>\\n<h3>1. 想法收集</h3>\\n<ul>\\n<li><strong>渠道</strong>：微信群、论坛置顶帖</li>\\n<li><strong>格式</strong>：简单说明做什么、为什么做、谁来用</li>\\n<li><strong>收集人</strong>：F组</li>\\n</ul>\\n<h3>2. 会议讨论</h3>\\n<ul>\\n<li><strong>组织</strong>：F组（策划部）负责安排</li>\\n<li><strong>时间</strong>：每周一次，线上会议</li>\\n<li><strong>内容</strong>：\\n<ol>\\n<li>新提案初筛</li>\\n<li>进行中项目进度同步</li>\\n<li>遇到的问题协调</li>\\n</ol>\\n</li>\\n</ul>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
