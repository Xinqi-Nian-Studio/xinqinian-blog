import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/share-sessions.html.vue"
const data = JSON.parse("{\"path\":\"/team/share-sessions.html\",\"title\":\"技术分享会\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":1.32,\"words\":395},\"filePathRelative\":\"team/share-sessions.md\",\"excerpt\":\"\\n<h2>基本情况</h2>\\n<ul>\\n<li><strong>地点</strong>：QQ群内进行</li>\\n<li><strong>形式</strong>：群内文字+截图讲解，或临时发起屏幕分享</li>\\n<li><strong>组织</strong>：F组（策划部）协调时间，有意分享者在群内接龙报名</li>\\n</ul>\\n<h2>分享安排</h2>\\n<p><strong>月度分享</strong>（每月一次）</p>\\n<ol>\\n<li>前一周F组在群内询问分享意向</li>\\n<li>确定1-2位分享人和大致时间</li>\\n<li>群公告通知具体安排</li>\\n</ol>\\n<p><strong>闪电分享</strong>（随时）</p>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
