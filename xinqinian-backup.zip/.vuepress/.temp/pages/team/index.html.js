import comp from "F:/Xinqi-Nian-Studio/.vuepress/.temp/pages/team/index.html.vue"
const data = JSON.parse("{\"path\":\"/team/\",\"title\":\"团队\",\"lang\":\"zh-CN\",\"frontmatter\":{},\"readingTime\":{\"minutes\":0.81,\"words\":242},\"filePathRelative\":\"team/README.md\",\"excerpt\":\"\\n<p>这里是新启年工作室的团队协作相关信息。</p>\\n<h2>团队成员</h2>\\n<p>了解我们的成员组成和各小组职能。工作室根据职能分为不同小组，共同协作完成项目。</p>\\n<p><a href=\\\"./members\\\">查看完整成员列表 →</a></p>\\n<h2>工作方式</h2>\\n<p>了解我们如何协作、沟通和推进项目。包括日常交流规范、会议制度和开发流程等。</p>\\n<ul>\\n<li><a href=\\\"./workflow\\\">工作流程</a> - 项目从想法到落地的完整流程</li>\\n<li><a href=\\\"./conventions\\\">协作规范</a> - 日常沟通与开发约定</li>\\n<li><a href=\\\"./share-sessions\\\">技术分享</a> - 定期与随时的技术交流</li>\\n</ul>\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
