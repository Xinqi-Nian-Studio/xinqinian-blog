<template><div><h1 id="技术分享会" tabindex="-1"><a class="header-anchor" href="#技术分享会"><span>技术分享会</span></a></h1>
<h2 id="基本情况" tabindex="-1"><a class="header-anchor" href="#基本情况"><span>基本情况</span></a></h2>
<ul>
<li><strong>地点</strong>：QQ群内进行</li>
<li><strong>形式</strong>：群内文字+截图讲解，或临时发起屏幕分享</li>
<li><strong>组织</strong>：F组（策划部）协调时间，有意分享者在群内接龙报名</li>
</ul>
<h2 id="分享安排" tabindex="-1"><a class="header-anchor" href="#分享安排"><span>分享安排</span></a></h2>
<p><strong>月度分享</strong>（每月一次）</p>
<ol>
<li>前一周F组在群内询问分享意向</li>
<li>确定1-2位分享人和大致时间</li>
<li>群公告通知具体安排</li>
</ol>
<p><strong>闪电分享</strong>（随时）</p>
<ul>
<li>任何人任何时候有想分享的小技巧、工具、踩坑经历</li>
<li>直接在群内说一声就可以开始分享</li>
<li>10-15分钟，简短直接</li>
</ul>
<h2 id="分享内容建议" tabindex="-1"><a class="header-anchor" href="#分享内容建议"><span>分享内容建议</span></a></h2>
<p><strong>技术相关即可</strong>，比如：</p>
<ul>
<li>最近做项目用到的一个不错的技术</li>
<li>某个常见问题的解决方法</li>
<li>推荐一个好用的开发工具或网站</li>
<li>学习某个新知识的经验和资源</li>
</ul>
<h2 id="流程" tabindex="-1"><a class="header-anchor" href="#流程"><span>流程</span></a></h2>
<ol>
<li>分享人提前准备好要讲的要点或截图</li>
<li>按约定时间在群内开始分享</li>
<li>过程中大家可以随时提问讨论</li>
<li>分享后把重点内容整理成一条总结消息（方便后来的人查看）</li>
</ol>
<h2 id="记录" tabindex="-1"><a class="header-anchor" href="#记录"><span>记录</span></a></h2>
<p>分享结束后，建议把主要内容整理成一篇简单的帖子，发到我们的论坛里存档。这样没来得及参加的人也能看到，以后也方便查找。</p>
<hr>
<p><strong>简单来说</strong>：就是大家在QQ群里定期或不定期地交流一些技术上的心得体会，形式随意，重在参与和交流。</p>
</div></template>


